#!/usr/bin/env bash


OKBLUE='\033[94m'
OKRED='\033[91m'
OKGREEN='\033[92m'
OKORANGE='\033[93m'
RESET='\e[0m'

echo -e "$OKRED $RESET"
echo -e "$OKRED $RESET"
echo -e "$OKRED                  $RESET"
echo -e "$OKRED                $RESET"
echo -e "$OKRED                $RESET"
echo -e "$OKRED              $RESET"
echo -e "$OKRED            $RESET"
echo -e "$OKRED           $RESET"
echo -e "$OKRED           $RESET"
echo -e "$OKRED  @Neferian  $RESET"
echo -e "$OKRED                 $RESET"
echo -e "$OKRED              $RESET"
echo -e "$OKRED $RESET"
echo ""
echo -e "$OKRED + -- --=[ https://t.me/DDoSEmpire $RESET"
echo -e "$OKRED + -- --=[ Nefrom by @Neferian $RESET"
echo ""

echo -e "$OKBLUE[*]$RESET Installing Nefrom... $RESET"
apt update
apt install -y python3 python3-requests python3-pip python3-lxml python3-requests openssl ca-certificates python3-dev wget git
cp -f $PWD/Nefrom /usr/bin/Nefrom
cp -f $PWD/injectx.py /usr/bin/injectx.py
cp -f $PWD/Nefrom.desktop /usr/share/applications/ 2> /dev/null
cp -f $PWD/Nefrom.desktop /usr/share/applications/Nefrom.desktop 2> /dev/null
cp -f $PWD/Nefrom.desktop /usr/share/kali-menu/applications/Nefrom.desktop2> /dev/null
echo -e "$OKBLUE[*]$RESET Done! $RESET"
echo -e "$OKRED[>]$RESET To run, type 'Nefrom'! $RESET"